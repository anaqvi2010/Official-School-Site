import { Button } from "@/components/ui/button";
import { Sprout, MapPin, Phone, Facebook, Book, GraduationCap, Palette } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground py-16 relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-10 left-10 opacity-5">
        <Book className="h-20 w-20 text-primary-foreground" />
      </div>
      <div className="absolute top-20 right-20 opacity-5">
        <GraduationCap className="h-24 w-24 text-primary-foreground" />
      </div>
      <div className="absolute bottom-10 left-1/4 opacity-5">
        <Palette className="h-16 w-16 text-primary-foreground" />
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 items-start">
          {/* Logo and Contact Actions */}
          <div className="text-center md:text-left animate-fade-in-up">
            <div className="flex items-center justify-center md:justify-start space-x-3 mb-6">
              <img 
                src="/lovable-uploads/8c239d05-3e13-4f72-b731-18c1bcced55a.png" 
                alt="Little Seeds Logo" 
                className="h-16 w-16 object-contain animate-float bg-primary-foreground/20 rounded-full p-2"
              />
              <h3 className="text-3xl font-bold">Little Seeds</h3>
            </div>
            
            <div className="space-y-4">
              <Link to="/programs">
                <Button
                  variant="outline"
                  className="w-full md:w-auto bg-primary-foreground/10 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/20"
                >
                  Inquire Now
                </Button>
              </Link>
              <Link to="/apply">
                <Button
                  variant="outline"
                  className="w-full md:w-auto bg-primary-foreground/10 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/20 ml-0 md:ml-4"
                >
                  Apply Today
                </Button>
              </Link>
            </div>
          </div>

          {/* Address and Directions */}
          <div className="text-center animate-fade-in-up [animation-delay:0.2s]">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <MapPin className="h-5 w-5" />
              <h4 className="text-lg font-semibold">Visit Us</h4>
            </div>
            <p className="text-primary-foreground/90 mb-4 leading-relaxed">
              951-2 Yeongtong-dong<br />
              Yeongtong-gu, Suwon-si<br />
              Gyeonggi-do, South Korea
            </p>
            <Button
              variant="outline"
              size="sm"
              className="bg-primary-foreground/10 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/20"
              onClick={() => window.open('https://www.google.com/maps/place/951-2+Yeongtong-dong,+Yeongtong-gu,+Suwon,+Gyeonggi-do/data=!3m2!1e3!4b1!4m6!3m5!1s0x357b5b2c6f78666b:0x81e1b7e2b19ec7ac!8m2!3d37.2653311!4d127.0767427!16s%2Fg%2F11bzgn2tjb?authuser=2&entry=ttu&g_ep=EgoyMDI1MDcxMy4wIKXMDSoASAFQAw%3D%3D', '_blank')}
            >
              Get Directions
            </Button>
          </div>

          {/* Contact and Social */}
          <div className="text-center animate-fade-in-up [animation-delay:0.4s]">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Phone className="h-5 w-5" />
              <h4 className="text-lg font-semibold">Contact</h4>
            </div>
            <p className="text-primary-foreground/90 mb-6 text-lg font-medium">
              031) 202-8279
            </p>
            
            <div className="flex justify-center space-x-4">
              <a
                href="https://www.facebook.com/littleseeds.englishkindergarten/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-primary-foreground/20 hover:bg-primary-foreground/30 rounded-full p-3 transition-all duration-300 hover:scale-110"
              >
                <Facebook className="h-6 w-6" />
              </a>
              <a
                href="https://blog.naver.com/viewsign/10043380516"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-primary-foreground/20 hover:bg-primary-foreground/30 rounded-full p-3 transition-all duration-300 hover:scale-110 font-bold text-sm flex items-center justify-center w-12 h-12"
              >
                N
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-primary-foreground/20 mt-12 pt-8 text-center animate-fade-in-up [animation-delay:0.6s]">
          <p className="text-primary-foreground/80 mb-2">
            © 2024 Little Seeds Kindergarten. Nurturing tomorrow's leaders today.
          </p>
          <p className="text-primary-foreground/60 text-sm">
            Website created by Azaan Naqvi
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;