import { Heart, Users, Star, TreePine, Book, GraduationCap, Palette } from "lucide-react";
import { Link } from "react-router-dom";

const AboutSection = () => {
  const values = [
    {
      icon: Heart,
      title: "Love & Care",
      description: "Every child receives individual attention and nurturing care in our warm environment"
    },
    {
      icon: Users,
      title: "Community",
      description: "Building strong relationships between children, families, and dedicated educators"
    },
    {
      icon: Star,
      title: "Excellence",
      description: "Providing the highest quality early childhood education with proven methods"
    },
    {
      icon: TreePine,
      title: "Growth",
      description: "Supporting each child's unique development and unlimited potential"
    }
  ];

  return (
    <section className="py-24 bg-gradient-to-b from-background to-secondary/15 relative overflow-hidden" data-section="about">
      {/* Elegant Background Elements */}
      <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-background/50 to-transparent"></div>
      <div className="absolute -top-12 -right-12 w-48 h-48 bg-accent/5 rounded-full blur-3xl"></div>
      <div className="absolute top-1/2 -left-24 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
      
      {/* Decorative School Elements */}
      <div className="absolute top-10 left-10 opacity-5">
        <Book className="h-24 w-24 text-primary animate-float" />
      </div>
      <div className="absolute top-20 right-16 opacity-5">
        <GraduationCap className="h-20 w-20 text-accent animate-float [animation-delay:1s]" />
      </div>
      <div className="absolute bottom-20 left-1/4 opacity-5">
        <Palette className="h-16 w-16 text-primary animate-float [animation-delay:2s]" />
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <div className="max-w-4xl mx-auto text-center mb-20 animate-fade-in-up">
          <h2 className="text-4xl md:text-6xl font-bold text-primary mb-8 relative">
            Where Little Minds Blossom
            <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-gradient-to-r from-accent to-accent-glow rounded-full"></div>
          </h2>
          <p className="text-lg md:text-xl text-foreground leading-relaxed max-w-3xl mx-auto">
            At Little Seeds Kindergarten, we believe that every child is a unique seed with unlimited potential. 
            Our nurturing environment provides the perfect foundation for young minds to grow, explore, and develop 
            into <span className="text-foreground font-semibold">confident</span>, <span className="text-foreground font-semibold">creative</span>, and <span className="text-foreground font-semibold">compassionate</span> individuals. 
            We foster a love of learning while building strong character foundations for lifelong success.
          </p>
        </div>

        {/* Values Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto mb-20">
          {values.map((value, index) => {
            const getRoute = (title: string) => {
              switch (title) {
                case "Love & Care": return "/love-care";
                case "Community": return "/community";
                case "Excellence": return "/excellence";
                case "Growth": return "/growth";
                default: return "/";
              }
            };

            return (
              <Link key={value.title} to={getRoute(value.title)}>
                <div
                  className="bg-background/80 backdrop-blur-sm rounded-3xl p-8 text-center shadow-xl border border-border/20 hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 animate-fade-in-up group relative overflow-hidden cursor-pointer"
                  style={{ animationDelay: `${index * 0.15}s` }}
                >
                  {/* Subtle gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  <div className="relative z-10">
                    <div className="bg-gradient-to-br from-primary/15 to-primary/10 rounded-2xl w-20 h-20 flex items-center justify-center mx-auto mb-6 group-hover:from-primary/25 group-hover:to-primary/15 transition-all duration-300 group-hover:scale-110">
                      <value.icon className="h-9 w-9 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold text-primary mb-4 group-hover:text-primary/90 transition-colors">{value.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{value.description}</p>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>

        {/* Elegant Call to Action */}
        <div className="text-center animate-fade-in-up [animation-delay:0.8s]">
          <div className="bg-background/90 backdrop-blur-sm rounded-3xl p-12 shadow-2xl border border-border/30 max-w-2xl mx-auto relative overflow-hidden">
            {/* Decorative element */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-accent/10 to-primary/10 rounded-full blur-2xl"></div>
            
            <div className="relative z-10">
              <p className="text-xl text-foreground mb-8 font-medium">
                Ready to plant the seeds of your child's future?
              </p>
              <div className="flex flex-col sm:flex-row gap-6 justify-center">
                <button 
                  className="bg-primary text-primary-foreground px-10 py-4 rounded-2xl font-semibold hover:bg-primary/90 transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 relative overflow-hidden group"
                  onClick={() => window.open('https://calendar.google.com/calendar/u/1/r/appointment?appttour&hl=en', '_blank')}
                >
                  <span className="relative z-10">Schedule a Visit</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-primary-glow to-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </button>
                <Link to="/programs">
                  <button className="bg-accent text-accent-foreground px-10 py-4 rounded-2xl font-semibold hover:bg-accent/90 transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 relative overflow-hidden group">
                    <span className="relative z-10">Learn About Programs</span>
                    <div className="absolute inset-0 bg-gradient-to-r from-accent-glow to-accent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;