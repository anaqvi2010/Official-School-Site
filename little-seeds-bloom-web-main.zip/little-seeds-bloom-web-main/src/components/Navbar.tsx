import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Sprout, Home, MessageCircle, FileText } from "lucide-react";
import { Link } from "react-router-dom";

const Navbar = () => {
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      const aboutSection = document.querySelector('[data-section="about"]') as HTMLElement;
      
      if (aboutSection) {
        const aboutPosition = aboutSection.offsetTop - 100;
        setIsVisible(currentScrollY < aboutPosition);
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [lastScrollY]);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm shadow-lg border-b border-border/50 transition-transform duration-300 ${isVisible ? 'translate-y-0' : '-translate-y-full'}`}>
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo and Name */}
          <div className="flex items-center space-x-3 animate-fade-in">
            <img 
              src="/lovable-uploads/8c239d05-3e13-4f72-b731-18c1bcced55a.png" 
              alt="Little Seeds Logo" 
              className="h-16 w-16 object-contain animate-float"
            />
            <h1 className="text-2xl font-bold text-primary">Little Seeds</h1>
          </div>

          {/* Navigation Links */}
          <div className="flex items-center space-x-8">
            <Link to="/">
              <Button variant="nav" className="font-medium flex items-center gap-2">
                <Home className="h-4 w-4" />
                Home
              </Button>
            </Link>
            <div className="h-6 w-px bg-border"></div>
            <Link to="/programs">
              <Button variant="nav" className="font-medium flex items-center gap-2">
                <MessageCircle className="h-4 w-4" />
                Inquire
              </Button>
            </Link>
            <div className="h-6 w-px bg-border"></div>
            <Link to="/apply">
              <Button variant="nav" className="font-medium flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Apply
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;