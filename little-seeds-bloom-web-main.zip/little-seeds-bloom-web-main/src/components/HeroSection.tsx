import { Button } from "@/components/ui/button";
import { Book, GraduationCap, Heart, Star, Sparkles } from "lucide-react";
import heroImage from "@/assets/hero-student-left.jpg";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Decorative School Elements */}
      <div className="absolute top-20 left-20 opacity-5">
        <Book className="h-16 w-16 text-primary animate-float" />
      </div>
      <div className="absolute top-40 right-10 opacity-5">
        <GraduationCap className="h-20 w-20 text-accent animate-float [animation-delay:1s]" />
      </div>
      <div className="absolute bottom-40 left-1/4 opacity-5">
        <Heart className="h-12 w-12 text-primary animate-float [animation-delay:2s]" />
      </div>
      <div className="absolute top-1/3 left-1/3 opacity-5">
        <Star className="h-8 w-8 text-accent animate-float [animation-delay:0.5s]" />
      </div>
      <div className="absolute bottom-1/4 right-1/3 opacity-5">
        <Sparkles className="h-14 w-14 text-primary animate-float [animation-delay:1.5s]" />
      </div>
      {/* Full Width Background Image */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Happy young student in kindergarten classroom"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-background/20 to-background/80"></div>
      </div>

      {/* Motto Content Box - Right Side */}
      <div className="relative z-10 ml-auto mr-8 lg:mr-16 w-full max-w-2xl">
        <div className="bg-background/95 backdrop-blur-md rounded-3xl p-12 lg:p-16 shadow-2xl border border-border/20 animate-scale-in mx-6 lg:mx-0">
          {/* School Motto - Centered Content */}
          <div className="text-center">
            <h2 className="text-3xl lg:text-5xl font-bold text-primary mb-8 leading-tight animate-fade-in-up">
              "Little Seeds Grow to Big Trees"
            </h2>
            
            <h3 className="text-3xl lg:text-5xl font-bold text-primary mb-12 animate-fade-in-up [animation-delay:0.2s]">
              "Little Seeds Grow to Future Leaders"
            </h3>

            {/* Learn More Button */}
            <a href="/programs">
              <Button
                variant="gold"
                size="lg"
                className="text-lg px-12 py-6 animate-fade-in-up [animation-delay:0.4s] relative overflow-hidden group shadow-lg"
              >
                <span className="relative z-10">Learn More</span>
                <div className="absolute inset-0 bg-gradient-to-r from-accent-glow to-accent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </Button>
            </a>
          </div>
        </div>
      </div>

      {/* Elegant Decorative Elements */}
      <div className="absolute top-1/4 right-1/4 w-24 h-24 bg-accent/10 rounded-full blur-2xl animate-float"></div>
      <div className="absolute bottom-1/3 right-1/6 w-16 h-16 bg-primary/15 rounded-full blur-xl animate-float [animation-delay:1.5s]"></div>
      <div className="absolute top-1/2 right-1/3 w-2 h-2 bg-accent rounded-full opacity-60 animate-float [animation-delay:0.8s]"></div>
      <div className="absolute top-1/3 right-1/5 w-1 h-1 bg-primary rounded-full opacity-80 animate-float [animation-delay:2s]"></div>
    </section>
  );
};

export default HeroSection;