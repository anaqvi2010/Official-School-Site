import { Button } from "@/components/ui/button";
import { GraduationCap, FileText, Heart, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const Apply = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 opacity-10">
        <GraduationCap className="h-16 w-16 text-primary" />
      </div>
      <div className="absolute top-40 right-16 opacity-10">
        <FileText className="h-12 w-12 text-accent" />
      </div>
      <div className="absolute bottom-40 left-20 opacity-10">
        <Heart className="h-14 w-14 text-primary" />
      </div>

      <div className="container mx-auto px-6 py-20">
        {/* Back Button */}
        <Link to="/" className="inline-flex items-center space-x-2 text-primary hover:text-primary/80 transition-colors mb-8">
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Home</span>
        </Link>
        
        <div className="max-w-4xl mx-auto text-center">
          {/* Welcome Title */}
          <h1 className="text-5xl lg:text-6xl font-bold text-primary mb-8 animate-fade-in">
            Welcome to Little Seeds
          </h1>
          <p className="text-xl text-muted-foreground mb-16 animate-fade-in [animation-delay:0.2s]">
            Begin Your Child's Journey of Growth and Discovery
          </p>

          {/* Principal's Welcome Letter */}
          <div className="bg-card rounded-3xl p-12 shadow-lg border border-border/20 mb-16 animate-scale-in [animation-delay:0.4s]">
            <h2 className="text-3xl font-bold text-primary mb-6">A Message from Our Principal</h2>
            <div className="text-lg text-foreground leading-relaxed space-y-4">
              <p>
                Dear Parents and Families,
              </p>
              <p>
                Welcome to Little Seeds, where every child is nurtured to grow into confident, creative, and compassionate individuals. We believe that like little seeds, children have unlimited potential waiting to bloom into something extraordinary.
              </p>
              <p>
                Our dedicated team of educators creates a warm, supportive environment where your child will develop essential life skills, form lasting friendships, and discover the joy of learning. We look forward to being part of your child's remarkable journey.
              </p>
              <p className="font-semibold">
                With warm regards,<br />
                Principal Cho
              </p>
            </div>
          </div>

          {/* Application Process */}
          <div className="bg-accent/5 rounded-3xl p-8 mb-16 animate-fade-in [animation-delay:0.6s]">
            <h3 className="text-2xl font-bold text-primary mb-4">Simple Application Process</h3>
            <p className="text-foreground leading-relaxed">
              Our application process is designed to be straightforward and welcoming. Simply click the button below to begin your application. 
              You'll be guided through each step, from basic information to scheduling a tour of our beautiful facility. 
              We're here to support you every step of the way and answer any questions you may have.
            </p>
          </div>

          {/* Start Application Button */}
          <Button
            variant="gold"
            size="lg"
            className="text-xl px-16 py-8 animate-fade-in [animation-delay:0.8s] shadow-lg hover:shadow-xl transition-all duration-300"
            onClick={() => window.open('https://docs.google.com/forms/d/e/1FAIpQLSchK8uwT8gehTty-9nTQFf71mNAbU6_uXx2_UiY49XM57chuQ/viewform?usp=sharing&ouid=110656407277928927031', '_blank')}
          >
            Start Application
          </Button>

          <p className="text-sm text-muted-foreground mt-4 animate-fade-in [animation-delay:1s]">
            Questions? Contact us at 031) 202-8279
          </p>
        </div>
      </div>
    </div>
  );
};

export default Apply;