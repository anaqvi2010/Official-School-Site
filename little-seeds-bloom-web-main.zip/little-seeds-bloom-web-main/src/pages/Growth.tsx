import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Sprout, TreePine, Smile, Heart, Palette } from "lucide-react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";

const Growth = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [timelineVisible, setTimelineVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
    const timer = setTimeout(() => setTimelineVisible(true), 1200);
    return () => clearTimeout(timer);
  }, []);

  const growthStages = [
    { icon: Sprout, title: "Seed", description: "Planting confidence and curiosity" },
    { icon: TreePine, title: "Sprout", description: "Growing independence and resilience" },
    { icon: TreePine, title: "Tree", description: "Flourishing with character and compassion" }
  ];

  const characterTraits = [
    {
      icon: Smile,
      title: "Confidence",
      description: "Building self-assurance through supportive encouragement and celebrating achievements, big and small.",
      color: "text-primary"
    },
    {
      icon: Heart,
      title: "Compassion", 
      description: "Fostering empathy and kindness towards others through community service and friendship building.",
      color: "text-accent"
    },
    {
      icon: Palette,
      title: "Creativity",
      description: "Encouraging artistic expression and innovative thinking through diverse creative outlets and exploration.",
      color: "text-secondary"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Floating Nature Elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            className={`absolute animate-float opacity-5`}
            style={{
              left: `${5 + i * 12}%`,
              top: `${10 + (i % 4) * 20}%`,
              animationDelay: `${i * 0.8}s`,
              animationDuration: `${6 + i * 0.3}s`
            }}
          >
            {i % 4 === 0 && <Sprout className="text-primary h-6 w-6" />}
            {i % 4 === 1 && <TreePine className="text-accent h-8 w-8" />}
            {i % 4 === 2 && <Heart className="text-secondary h-5 w-5" />}
            {i % 4 === 3 && <div className="w-2 h-2 bg-primary rounded-full"></div>}
          </div>
        ))}
      </div>

      {/* Hero Section with Parallax Effect */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/15 via-accent/10 to-secondary/15"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent"></div>
        
        {/* Animated Background Elements */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-primary/10 to-transparent animate-pulse"></div>
        
        <div className={`relative z-10 text-center px-6 max-w-4xl mx-auto transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h1 className="text-5xl md:text-6xl font-bold text-primary mb-6 animate-fade-in">
            Nurturing Roots for Lifelong Growth
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed animate-fade-in [animation-delay:0.3s]">
            We emphasize character development, independence, confidence, and resilience. Like a garden 
            carefully tended, we provide the right environment for each child to develop strong roots 
            and flourish into their unique, wonderful selves.
          </p>
          <Link to="/">
            <Button 
              variant="outline" 
              className="mt-8 animate-fade-in [animation-delay:0.6s] hover:scale-105 transition-transform"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
      </section>

      {/* Growth Timeline */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-primary mb-16 animate-fade-in">
            Journey of Growth
          </h2>
          
          <div className="relative">
            {/* Timeline Line */}
            <div className={`absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-gradient-to-b from-primary via-accent to-secondary transition-all duration-2000 ${timelineVisible ? 'opacity-100 scale-y-100' : 'opacity-0 scale-y-0'}`}></div>
            
            <div className="space-y-16">
              {growthStages.map((stage, index) => (
                <div 
                  key={index}
                  className={`flex items-center ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'} animate-fade-in`}
                  style={{ animationDelay: `${index * 0.4 + 1}s` }}
                >
                  <div className={`flex-1 ${index % 2 === 0 ? 'text-right pr-8' : 'text-left pl-8'}`}>
                    <div className="bg-card rounded-xl p-6 shadow-lg border border-border hover:shadow-xl transition-all duration-300 hover:scale-105">
                      <h3 className="text-2xl font-bold text-primary mb-3">{stage.title}</h3>
                      <p className="text-muted-foreground">{stage.description}</p>
                    </div>
                  </div>
                  
                  <div className="relative z-10 bg-primary rounded-full p-4 shadow-lg">
                    <stage.icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  
                  <div className="flex-1"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Character Traits Section */}
      <section className="py-16 bg-gradient-to-r from-primary/5 to-accent/5">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-4xl font-bold text-center text-primary mb-16">
            Character We Cultivate
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {characterTraits.map((trait, index) => (
              <div 
                key={index}
                className={`bg-card rounded-xl p-8 shadow-lg border border-border hover:shadow-xl transition-all duration-300 hover:scale-105 animate-fade-in group cursor-pointer`}
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="mb-6 flex justify-center">
                  <div className="bg-primary/10 rounded-full p-4 group-hover:bg-primary/20 transition-colors group-hover:scale-110 duration-300">
                    <trait.icon className={`h-8 w-8 ${trait.color} group-hover:scale-110 transition-transform`} />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-4 text-center">
                  {trait.title}
                </h3>
                <p className="text-muted-foreground text-center leading-relaxed">
                  {trait.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Growth Philosophy */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto text-center px-6">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <Sprout className="h-16 w-16 text-primary animate-pulse" />
              <div className="absolute inset-0 bg-primary/20 rounded-full blur-xl animate-ping"></div>
            </div>
          </div>
          <h3 className="text-3xl font-bold text-primary mb-6">
            Every Child Grows at Their Own Pace
          </h3>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Just as every seed grows into a unique plant, every child develops their own special 
            qualities and strengths. We provide the nurturing environment, patience, and support 
            needed for each child to bloom into their fullest potential, celebrating every milestone 
            along their individual journey.
          </p>
        </div>
      </section>

      {/* Bottom Navigation */}
      <section className="py-12 text-center">
        <Link to="/">
          <Button 
            size="lg"
            className="hover:scale-105 transition-transform"
          >
            <ArrowLeft className="mr-2 h-5 w-5" />
            Return to Home
          </Button>
        </Link>
      </section>
    </div>
  );
};

export default Growth;