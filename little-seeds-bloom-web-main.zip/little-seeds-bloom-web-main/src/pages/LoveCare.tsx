import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Heart, Users, Shield, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";

const LoveCare = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const features = [
    {
      icon: Users,
      title: "Small Class Sizes",
      description: "Personal attention with low teacher-to-student ratios ensuring every child feels valued and supported."
    },
    {
      icon: Heart,
      title: "Warm Classrooms",
      description: "Thoughtfully designed spaces that feel like home, creating comfort and security for young learners."
    },
    {
      icon: Shield,
      title: "Trained Caregivers",
      description: "Experienced and certified staff dedicated to nurturing each child's emotional and physical well-being."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Floating Hearts Animation */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        {[...Array(6)].map((_, i) => (
          <Heart 
            key={i}
            className={`absolute text-primary/10 animate-float`}
            style={{
              left: `${20 + i * 15}%`,
              top: `${10 + (i % 3) * 30}%`,
              animationDelay: `${i * 0.5}s`,
              animationDuration: `${4 + i * 0.5}s`
            }}
            size={24 + (i % 3) * 8}
          />
        ))}
      </div>

      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-accent/10 to-secondary/20"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent"></div>
        
        <div className={`relative z-10 text-center px-6 max-w-4xl mx-auto transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h1 className="text-5xl md:text-6xl font-bold text-primary mb-6 animate-fade-in">
            Where Love Nurtures Every Little Heart
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed animate-fade-in [animation-delay:0.3s]">
            At Little Seeds, we believe that love is the foundation of all learning. Our nurturing environment 
            prioritizes emotional well-being, safety, and creating a second home where every child feels cherished, 
            understood, and empowered to grow at their own pace.
          </p>
          <Link to="/">
            <Button 
              variant="outline" 
              className="mt-8 animate-fade-in [animation-delay:0.6s] hover:scale-105 transition-transform"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-primary mb-16 animate-fade-in">
            Our Loving Approach
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div 
                key={index}
                className={`bg-card rounded-xl p-8 shadow-lg border border-border hover:shadow-xl transition-all duration-300 hover:scale-105 animate-fade-in group`}
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="mb-6 flex justify-center">
                  <div className="bg-primary/10 rounded-full p-4 group-hover:bg-primary/20 transition-colors">
                    <feature.icon className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-4 text-center">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground text-center leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Sparkles Section */}
      <section className="py-16 bg-gradient-to-r from-primary/5 to-accent/5">
        <div className="max-w-4xl mx-auto text-center px-6">
          <div className="flex justify-center mb-6">
            <Sparkles className="h-12 w-12 text-primary animate-pulse" />
          </div>
          <h3 className="text-3xl font-bold text-primary mb-6">
            Every Child Deserves to Feel Loved
          </h3>
          <p className="text-lg text-muted-foreground leading-relaxed">
            We create an atmosphere where children feel safe to express themselves, make mistakes, 
            learn, and grow. Our dedicated team ensures that love and care are woven into every 
            interaction, every lesson, and every moment of your child's day.
          </p>
        </div>
      </section>

      {/* Bottom Navigation */}
      <section className="py-12 text-center">
        <Link to="/">
          <Button 
            size="lg"
            className="hover:scale-105 transition-transform"
          >
            <ArrowLeft className="mr-2 h-5 w-5" />
            Return to Home
          </Button>
        </Link>
      </section>
    </div>
  );
};

export default LoveCare;