import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Users, Calendar, Globe, Star } from "lucide-react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";

const Community = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const highlights = [
    {
      icon: Calendar,
      title: "Family Days",
      description: "Regular events that bring families together to celebrate milestones, share experiences, and build lasting connections.",
      image: "🎪"
    },
    {
      icon: Globe,
      title: "Cultural Celebrations",
      description: "Embracing diversity through festivals and traditions that teach children about the beautiful world around them.",
      image: "🌍"
    },
    {
      icon: Users,
      title: "Parent-Teacher Engagement",
      description: "Open communication channels and regular collaboration to ensure every child's success and well-being.",
      image: "🤝"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Floating Elements Animation */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        {[...Array(8)].map((_, i) => (
          <div 
            key={i}
            className={`absolute animate-float transition-opacity duration-1000 ${isVisible ? 'opacity-20' : 'opacity-0'}`}
            style={{
              left: `${10 + i * 12}%`,
              top: `${5 + (i % 4) * 25}%`,
              animationDelay: `${i * 0.7}s`,
              animationDuration: `${5 + i * 0.3}s`
            }}
          >
            {i % 2 === 0 ? (
              <Star className="text-primary/8 h-6 w-6" />
            ) : (
              <div className="w-3 h-3 bg-accent/20 rounded-full"></div>
            )}
          </div>
        ))}
      </div>

      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-accent/20 via-primary/10 to-secondary/20"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent"></div>
        
        <div className={`relative z-10 text-center px-6 max-w-4xl mx-auto transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h1 className="text-5xl md:text-6xl font-bold text-primary mb-6 animate-fade-in">
            Together, We Grow Stronger
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed animate-fade-in [animation-delay:0.3s]">
            Our school thrives on the strong bonds we build between parents, teachers, and students. 
            Through open communication, shared experiences, and collaborative events, we create a 
            community where every family feels welcomed, valued, and connected.
          </p>
          <Link to="/">
            <Button 
              variant="outline" 
              className="mt-8 animate-fade-in [animation-delay:0.6s] hover:scale-105 transition-transform"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
      </section>

      {/* Highlights Section */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-primary mb-16 animate-fade-in">
            Building Our Community
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {highlights.map((highlight, index) => (
              <div 
                key={index}
                className={`bg-card rounded-xl p-8 shadow-lg border border-border hover:shadow-xl transition-all duration-300 hover:scale-105 animate-fade-in group cursor-pointer`}
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="mb-6 flex justify-center">
                  <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">
                    {highlight.image}
                  </div>
                </div>
                <div className="flex justify-center mb-4">
                  <div className="bg-primary/10 rounded-full p-3 group-hover:bg-primary/20 transition-colors">
                    <highlight.icon className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-4 text-center">
                  {highlight.title}
                </h3>
                <p className="text-muted-foreground text-center leading-relaxed">
                  {highlight.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Community Values Section */}
      <section className="py-16 bg-gradient-to-r from-accent/5 to-primary/5">
        <div className="max-w-4xl mx-auto text-center px-6">
          <div className="flex justify-center mb-6">
            <Users className="h-12 w-12 text-primary animate-pulse" />
          </div>
          <h3 className="text-3xl font-bold text-primary mb-6">
            A Circle of Support
          </h3>
          <p className="text-lg text-muted-foreground leading-relaxed mb-8">
            We believe that a child's education is most successful when families and school work 
            hand in hand. Our community extends beyond the classroom, creating lasting friendships 
            and support networks that benefit children and families for years to come.
          </p>
          <div className="grid md:grid-cols-2 gap-8 mt-12">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary mb-2">15+</div>
              <div className="text-muted-foreground">Annual Community Events</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary mb-2">100%</div>
              <div className="text-muted-foreground">Parent Participation</div>
            </div>
          </div>
        </div>
      </section>

      {/* Bottom Navigation */}
      <section className="py-12 text-center">
        <Link to="/">
          <Button 
            size="lg"
            className="hover:scale-105 transition-transform"
          >
            <ArrowLeft className="mr-2 h-5 w-5" />
            Return to Home
          </Button>
        </Link>
      </section>
    </div>
  );
};

export default Community;