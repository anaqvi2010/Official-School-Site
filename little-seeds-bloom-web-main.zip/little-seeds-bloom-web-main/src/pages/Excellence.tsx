import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Award, BookOpen, Lightbulb, TrendingUp } from "lucide-react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";

const Excellence = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [statsAnimated, setStatsAnimated] = useState(false);

  useEffect(() => {
    setIsVisible(true);
    const timer = setTimeout(() => setStatsAnimated(true), 1000);
    return () => clearTimeout(timer);
  }, []);

  const stats = [
    { number: "1:8", label: "Teacher-to-Student Ratio", icon: Award },
    { number: "95%", label: "School Readiness Rate", icon: TrendingUp },
    { number: "20+", label: "Learning Milestones", icon: BookOpen }
  ];

  const CountUpNumber = ({ target, suffix = "" }: { target: string; suffix?: string }) => {
    return (
      <div className={`text-4xl font-bold text-primary transition-all duration-1000 ${statsAnimated ? 'opacity-100 scale-100' : 'opacity-0 scale-90'}`}>
        {target}{suffix}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Floating Educational Icons */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        {[...Array(6)].map((_, i) => (
          <div
            key={i}
            className={`absolute animate-float transition-opacity duration-1000 ${isVisible ? 'opacity-20' : 'opacity-0'}`}
            style={{
              left: `${15 + i * 14}%`,
              top: `${8 + (i % 3) * 28}%`,
              animationDelay: `${i * 0.6}s`,
              animationDuration: `${4 + i * 0.4}s`
            }}
          >
            {i % 3 === 0 && <BookOpen className="text-primary/8 h-8 w-8" />}
            {i % 3 === 1 && <Lightbulb className="text-accent/8 h-6 w-6" />}
            {i % 3 === 2 && <Award className="text-secondary/8 h-7 w-7" />}
          </div>
        ))}
      </div>

      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-secondary/20 via-primary/10 to-accent/20"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent"></div>
        
        {/* Spotlight Effect */}
        <div className="absolute top-1/4 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-radial from-primary/20 to-transparent rounded-full blur-3xl animate-pulse"></div>
        
        <div className={`relative z-10 text-center px-6 max-w-4xl mx-auto transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <h1 className="text-5xl md:text-6xl font-bold text-primary mb-6 animate-fade-in">
            Inspiring Lifelong Excellence
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed animate-fade-in [animation-delay:0.3s]">
            We nurture curiosity, foster academic readiness, and ignite a passion for learning through 
            our carefully crafted, play-based curriculum. Every child is encouraged to reach their 
            full potential while developing critical thinking skills and a love for discovery.
          </p>
          <Link to="/">
            <Button 
              variant="outline" 
              className="mt-8 animate-fade-in [animation-delay:0.6s] hover:scale-105 transition-transform"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-primary mb-16 animate-fade-in">
            Excellence in Numbers
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {stats.map((stat, index) => (
              <div 
                key={index}
                className={`bg-card rounded-xl p-8 shadow-lg border border-border text-center hover:shadow-xl transition-all duration-300 hover:scale-105 animate-fade-in group`}
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="mb-6 flex justify-center">
                  <div className="bg-primary/10 rounded-full p-4 group-hover:bg-primary/20 transition-colors">
                    <stat.icon className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <CountUpNumber target={stat.number} />
                <p className="text-muted-foreground mt-2 font-medium">
                  {stat.label}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Excellence Features */}
      <section className="py-16 bg-gradient-to-r from-primary/5 to-accent/5">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in">
              <h3 className="text-3xl font-bold text-primary mb-6">
                Our Approach to Excellence
              </h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-primary/10 rounded-full p-2 mt-1">
                    <Lightbulb className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Curiosity-Driven Learning</h4>
                    <p className="text-muted-foreground">Encouraging questions and exploration through hands-on activities and guided discovery.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-primary/10 rounded-full p-2 mt-1">
                    <BookOpen className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Academic Readiness</h4>
                    <p className="text-muted-foreground">Building strong foundations in literacy, numeracy, and critical thinking skills.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-primary/10 rounded-full p-2 mt-1">
                    <Award className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Individual Achievement</h4>
                    <p className="text-muted-foreground">Celebrating each child's unique strengths and supporting their personal growth journey.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex justify-center animate-fade-in [animation-delay:0.3s]">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full blur-2xl"></div>
                <div className="relative bg-card rounded-2xl p-8 shadow-xl border border-border">
                  <div className="text-center">
                    <TrendingUp className="h-16 w-16 text-primary mx-auto mb-4" />
                    <h4 className="text-xl font-bold text-foreground mb-2">Proven Results</h4>
                    <p className="text-muted-foreground">Our students consistently exceed readiness benchmarks</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Bottom Navigation */}
      <section className="py-12 text-center">
        <Link to="/">
          <Button 
            size="lg"
            className="hover:scale-105 transition-transform"
          >
            <ArrowLeft className="mr-2 h-5 w-5" />
            Return to Home
          </Button>
        </Link>
      </section>
    </div>
  );
};

export default Excellence;