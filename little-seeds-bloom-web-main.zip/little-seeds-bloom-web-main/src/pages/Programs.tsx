import { Button } from "@/components/ui/button";
import { ArrowLeft, Book, GraduationCap, Palette, Apple, Blocks, PenTool, Globe, Microscope, Calculator, Heart, Users, Star, TreePine } from "lucide-react";
import { Link } from "react-router-dom";

const Programs = () => {
  const programs = [
    {
      title: "Early Kindergarten",
      age: "Ages 3-4",
      description: "Building the foundation for lifelong learning through play-based exploration",
      features: [
        "Social skills development through guided play",
        "Sensory exploration activities",
        "Language development through stories and songs",
        "Basic math concepts with hands-on manipulatives",
        "Fine motor skill development",
        "Introduction to letters and sounds"
      ],
      color: "from-primary/20 to-primary/10"
    },
    {
      title: "Kindergarten",
      age: "Ages 5-6",
      description: "Developing essential academic skills in a nurturing, creative environment",
      features: [
        "Foundational literacy and phonics instruction",
        "Mathematical thinking and problem-solving",
        "Science exploration and discovery",
        "Creative arts and self-expression",
        "Social-emotional learning",
        "Introduction to technology and digital literacy"
      ],
      color: "from-accent/20 to-accent/10"
    },
    {
      title: "First Grade",
      age: "Ages 6-7",
      description: "Building confidence in reading, writing, and mathematical reasoning",
      features: [
        "Advanced reading comprehension strategies",
        "Creative writing and storytelling",
        "Hands-on science experiments and projects",
        "Mathematical problem-solving and critical thinking",
        "Introduction to social studies and community",
        "Character development and leadership skills"
      ],
      color: "from-primary/15 to-accent/15"
    },
    {
      title: "Second Grade",
      age: "Ages 7-8",
      description: "Fostering independent thinking and advanced academic skills",
      features: [
        "Advanced reading comprehension and analysis",
        "Research skills and information literacy",
        "Environmental science and sustainability",
        "Introduction to coding and computational thinking",
        "Historical thinking and cultural awareness",
        "Advanced mathematical concepts and reasoning"
      ],
      color: "from-accent/15 to-primary/20"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 opacity-10">
        <Book className="h-16 w-16 text-primary animate-float" />
      </div>
      <div className="absolute top-40 right-16 opacity-10">
        <GraduationCap className="h-12 w-12 text-accent animate-float [animation-delay:1s]" />
      </div>
      <div className="absolute bottom-40 left-20 opacity-10">
        <Palette className="h-14 w-14 text-primary animate-float [animation-delay:2s]" />
      </div>
      <div className="absolute top-60 right-32 opacity-8">
        <Apple className="h-10 w-10 text-accent animate-float [animation-delay:0.5s]" />
      </div>
      <div className="absolute bottom-60 right-20 opacity-8">
        <Blocks className="h-12 w-12 text-primary animate-float [animation-delay:1.5s]" />
      </div>
      <div className="absolute top-80 left-32 opacity-8">
        <PenTool className="h-8 w-8 text-accent animate-float [animation-delay:2.5s]" />
      </div>

      <div className="container mx-auto px-6 py-20">
        {/* Back Button */}
        <Link to="/" className="inline-flex items-center space-x-2 text-primary hover:text-primary/80 transition-colors mb-8">
          <ArrowLeft className="h-5 w-5" />
          <span>Back to Home</span>
        </Link>

        {/* Header Section */}
        <div className="max-w-4xl mx-auto text-center mb-20 animate-fade-in">
          <h1 className="text-5xl lg:text-6xl font-bold text-primary mb-8">
            Our Programs
          </h1>
          <p className="text-xl text-muted-foreground mb-8">
            Comprehensive academic excellence from early kindergarten through second grade
          </p>
          <div className="bg-card rounded-3xl p-8 shadow-lg border border-border/20">
            <p className="text-lg text-foreground leading-relaxed">
              At Little Seeds, our programs are carefully designed by qualified, experienced educators 
              who understand child development. Our teachers hold advanced degrees in early childhood 
              education and are passionate about nurturing each child's unique potential through 
              innovative, research-based teaching methods.
            </p>
          </div>
        </div>

        {/* Programs Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-7xl mx-auto mb-20">
          {programs.map((program, index) => (
            <div
              key={program.title}
              className="bg-background/80 backdrop-blur-sm rounded-3xl p-8 shadow-xl border border-border/20 hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 animate-fade-in relative overflow-hidden"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              {/* Gradient Overlay */}
              <div className={`absolute inset-0 bg-gradient-to-br ${program.color} rounded-3xl`}></div>
              
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-2xl font-bold text-primary">{program.title}</h3>
                  <span className="bg-accent/20 text-accent-foreground px-4 py-2 rounded-full text-sm font-medium">
                    {program.age}
                  </span>
                </div>
                
                <p className="text-foreground/80 mb-6 leading-relaxed">{program.description}</p>
                
                <div className="space-y-3">
                  <h4 className="font-semibold text-primary mb-3">Program Highlights:</h4>
                  {program.features.map((feature, idx) => (
                    <div key={idx} className="flex items-start space-x-3">
                      <div className="bg-primary/20 rounded-full p-1 mt-1">
                        <div className="w-2 h-2 bg-primary rounded-full"></div>
                      </div>
                      <span className="text-muted-foreground text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Teacher Quality Section */}
        <div className="bg-gradient-to-r from-primary/5 to-accent/5 rounded-3xl p-12 mb-16 animate-fade-in [animation-delay:0.8s]">
          <div className="max-w-4xl mx-auto text-center">
            <div className="flex justify-center space-x-6 mb-8">
              <div className="bg-primary/20 rounded-full p-4">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <div className="bg-accent/20 rounded-full p-4">
                <Star className="h-8 w-8 text-accent" />
              </div>
              <div className="bg-primary/20 rounded-full p-4">
                <Heart className="h-8 w-8 text-primary" />
              </div>
            </div>
            <h2 className="text-3xl font-bold text-primary mb-6">Exceptional Teaching Excellence</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div>
                <h3 className="font-semibold text-primary mb-2">Qualified Educators</h3>
                <p className="text-muted-foreground">Advanced degrees in early childhood education and ongoing professional development</p>
              </div>
              <div>
                <h3 className="font-semibold text-primary mb-2">Low Student-Teacher Ratio</h3>
                <p className="text-muted-foreground">Ensuring personalized attention and individualized learning for every child</p>
              </div>
              <div>
                <h3 className="font-semibold text-primary mb-2">Passionate Commitment</h3>
                <p className="text-muted-foreground">Dedicated to fostering each child's academic, social, and emotional growth</p>
              </div>
            </div>
          </div>
        </div>

        {/* Newsletter Section */}
        <div className="bg-card rounded-3xl p-12 mb-16 shadow-lg border border-border/20 animate-fade-in [animation-delay:1s]">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-primary mb-6">This Month's Newsletter</h2>
            <div className="min-h-[200px] flex items-center justify-center bg-muted/30 rounded-2xl border border-border/50">
              <p className="text-muted-foreground text-lg">Newsletter content will be added here</p>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center animate-fade-in [animation-delay:1s]">
          <div className="bg-background/90 backdrop-blur-sm rounded-3xl p-12 shadow-2xl border border-border/30 max-w-2xl mx-auto relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-accent/10 to-primary/10 rounded-full blur-2xl"></div>
            
            <div className="relative z-10">
              <h3 className="text-2xl font-bold text-primary mb-4">Ready to Learn More?</h3>
              <p className="text-foreground mb-8">
                Schedule a visit to see our programs in action and meet our exceptional teaching team.
              </p>
              <div className="flex flex-col sm:flex-row gap-6 justify-center">
                <button 
                  className="bg-primary text-primary-foreground px-10 py-4 rounded-2xl font-semibold hover:bg-primary/90 transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105"
                  onClick={() => window.open('https://calendar.google.com/calendar/u/1/r/appointment?appttour&hl=en', '_blank')}
                >
                  Schedule a Visit
                </button>
                <Link to="/apply">
                  <button className="bg-accent text-accent-foreground px-10 py-4 rounded-2xl font-semibold hover:bg-accent/90 transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105">
                    Apply Today
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Programs;